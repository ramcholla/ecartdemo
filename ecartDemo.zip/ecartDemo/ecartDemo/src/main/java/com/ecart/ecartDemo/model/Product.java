package com.ecart.ecartDemo.model;

public class Product {
	
	private String productId;
	private String productName;
	private String ProductDesc;
	private String productImage;
	private float productPrice;
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDesc() {
		return ProductDesc;
	}
	public void setProductDesc(String productDesc) {
		ProductDesc = productDesc;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", ProductDesc=" + ProductDesc
				+ ", productImage=" + productImage + ", productPrice=" + productPrice + "]";
	}
	public Product(String productId, String productName, String productDesc, String productImage, float productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		ProductDesc = productDesc;
		this.productImage = productImage;
		this.productPrice = productPrice;
	}
	public Product() {
		
	}

}
