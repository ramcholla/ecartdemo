package com.ecart.ecartDemo.model;

public class Login {

	
	private String firstName;
	private String lastName;
	private String email;
	private String password;
	private String userName;
	private String message;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "Login [firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", password="
				+ password + ", userName=" + userName + ", message=" + message + "]";
	}
	public Login(String firstName, String lastName, String email, String password, String userName, String message) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.userName = userName;
		this.message = message;
	}
	public Login() {
		
	}
}
