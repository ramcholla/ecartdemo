package com.ecart.ecartDemo.daoImpl;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.ecart.ecartDemo.dao.IProductDao;
import com.ecart.ecartDemo.model.Login;
import com.ecart.ecartDemo.model.Product;

@Repository
public class ProductDaoImpl implements IProductDao{

	@Override
	public Login registerUser(Login dto) {
		
		Login login=null;
		try {
			 login=new Login();
			String firstName=dto.getFirstName();
			String lastName=dto.getLastName();
			String useremail=dto.getEmail();
			String password=dto.getPassword();
			String username=dto.getUserName();
			if(!StringUtils.isEmpty(username) && !StringUtils.isEmpty(password)) {
				
				 login.setMessage("User Registered Successfully");
			}else {
				login.setMessage("Unable to Register the User");
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return login;
		
	}

	@Override
	public List<Product> productDetailsList() {
		
		List<Product> prodList=Arrays.asList(
			
				new Product("12","Dell Computer","Dell Computer","dell.png",30000),
				new Product("13","Lenovo Computer","Lenovo Computer","lenovo.png",33000),
				new Product("14","Acer Computer","Acer Computer","acer.png",25000),
				new Product("15","Philips","Philips","philips.png",1200),
				new Product("16","Casio","Casio Watches","casio.png",5000),
				new Product("18","Apple","Apple Computer","apple.png",60000),
				new Product("19","SamSung Mobiles","SamSung Mobiles","samsung.png",15000)
				);
		
		return prodList;
	}

	@Override
	public Product productDetails(String prodId) {
		
		Product prodDetails=productDetailsList().stream().filter(p->p.getProductId().equals(prodId)).
				findAny().orElse(null);
				
		return prodDetails;
	}

	@Override
	public Login loginUser(Login dto) {
		
		Login login=null;
		try {
			login=new Login();
			String username=dto.getUserName();
			String password=dto.getPassword();
			
			
			if(username.equalsIgnoreCase("Ram") && password.equals("12345")) {
				
				login.setMessage("Login Success");
			}else {
				login.setMessage("Incorrect Username/Password");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return login;
	}

	
}
