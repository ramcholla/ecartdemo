package com.ecart.ecartDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcartDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcartDemoApplication.class, args);
	}

}
