package com.ecart.ecartDemo.service;

import java.util.List;

import com.ecart.ecartDemo.model.Login;
import com.ecart.ecartDemo.model.Product;

public interface IProductService {

	Login registerUser(Login dto);

	List<Product> productDetailsList();

	Product productDetails(String prodId);

	Login loginUser(Login dto);

}
