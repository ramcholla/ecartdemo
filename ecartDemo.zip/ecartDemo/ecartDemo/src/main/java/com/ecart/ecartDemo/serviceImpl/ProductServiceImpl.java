package com.ecart.ecartDemo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecart.ecartDemo.dao.IProductDao;
import com.ecart.ecartDemo.model.Login;
import com.ecart.ecartDemo.model.Product;
import com.ecart.ecartDemo.service.IProductService;

@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	private IProductDao dao;
	
	@Override
	public Login registerUser(Login dto) {
		// TODO Auto-generated method stub
		return dao.registerUser(dto);
	}

	@Override
	public List<Product> productDetailsList() {
		// TODO Auto-generated method stub
		return dao.productDetailsList();
	}

	@Override
	public Product productDetails(String prodId) {
		// TODO Auto-generated method stub
		return dao.productDetails(prodId);
	}

	@Override
	public Login loginUser(Login dto) {
		// TODO Auto-generated method stub
		return dao.loginUser(dto);
	}

}
