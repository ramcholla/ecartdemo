package com.ecart.ecartDemo.dao;

import java.util.List;

import com.ecart.ecartDemo.model.Login;
import com.ecart.ecartDemo.model.Product;

public interface IProductDao {

	Login registerUser(Login dto);

	List<Product> productDetailsList();

	Product productDetails(String prodId);

	Login loginUser(Login dto);

}
