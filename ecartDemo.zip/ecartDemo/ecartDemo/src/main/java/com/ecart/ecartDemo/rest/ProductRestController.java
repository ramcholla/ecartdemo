package com.ecart.ecartDemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ecart.ecartDemo.model.Login;
import com.ecart.ecartDemo.model.Product;
import com.ecart.ecartDemo.service.IProductService;

@RestController
public class ProductRestController {
	
	@Autowired
	private IProductService prodService;
	
	@PostMapping(value="/registerUser",produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Login> registerUser(@RequestBody Login dto){
		
		Login registeDto=prodService.registerUser(dto);
		
		return new ResponseEntity<Login>(registeDto,HttpStatus.OK);
	};
	@PostMapping(value="/loginUser",produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Login> loginUser(@RequestBody Login dto){
		
		Login loginDto=prodService.loginUser(dto);
		
		return new ResponseEntity<Login>(loginDto,HttpStatus.OK);
	};
	@GetMapping(value="/productDetails",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Product>> productDetailsList(){
		
		List<Product> productList=prodService.productDetailsList();
		
		return new ResponseEntity<List<Product>>(productList,HttpStatus.OK);
	};
	@GetMapping(value="/productDetails/{productId}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Product> productDetails(@PathVariable("productId") String prodId){
		
		Product productList=prodService.productDetails(prodId);
		
		return new ResponseEntity<Product>(productList,HttpStatus.OK);
	};
	

}
