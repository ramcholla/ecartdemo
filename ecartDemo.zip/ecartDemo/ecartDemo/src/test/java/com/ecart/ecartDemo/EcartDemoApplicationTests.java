package com.ecart.ecartDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcartDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
